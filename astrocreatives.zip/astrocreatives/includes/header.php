	<header id="masthead" class="site-header" role="banner">
			<a class="home-link" href="index.html" title="AstroCreatives" rel="home">
				<h1 class="site-title">AstroCreatives</h1>
				<h2 class="site-description">Your Design our priority</h2>
			</a>

			<div class="menu-meta-site">
				<div class="menu-meta-site-container">
					<ul class="menu-meta-site-links">
						
						<a href="donate.html"><li class="link-button primary">Donate</li></a>
					</ul>
					<a title="AstroCreatives" href="https://www.ieconline.us/AstroCreatives/index.php"><img src="images/ASTRO-LOGO.svg" alt="AstroCreatives" class="tclogo-for"></a>
				</div>
			</div>

			<div id="navbar" class="navbar">
				<a title="AstroCreatives" href="index.html">
					<img width="171" height="67" src="ASTRO-LOGO.svg" alt="AstroCreatives" class="tclogo">
				<img src="ASTRO-LOGO.svg" alt="AstroCreatives" class="tclogo-extended">
			</a>
				<nav id="site-navigation" class="navigation main-navigation" role="navigation">
					<button class="menu-toggle">Menu</button>
					<ul id="mobile-menu">
						<li id="mobile-menu-logo" class="menu-item menu-image menu-item-type-post_type menu-item-object-page menu-item-16">
						    <a title="AstroCreatives" href="index.html"><img width="48" height="29" src="ASTRO-LOGO.svg" alt="ASTROCREATIVES"></a></li>
						<li id="mobile-menu-login" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-75"><a href="donate.html" class="menu-image-title-after"><span class="menu-image-title">Donate</span></a></li>
					</ul>
					<a class="screen-reader-text skip-link" href="#" title="Skip to content">Skip to content</a>
					<div class="menu-main-menu-container"><ul id="primary-menu" class="nav-menu">
<li id="menu-item-11511" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-11483 current_page_item menu-item-11511">
    <a href="index.php" aria-current="page">Home</a></li>
<li id="menu-item-11433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11433"><a href="#section1">About Me</a></li>
<li id="menu-item-29" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29"><a href="projects.php">Projects</a></li>
<li id="menu-item-11439" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11439"><a href="#testimos">Testimonials</a></li>
<li id="menu-item-31" class="section-news menu-item menu-item-type-taxonomy menu-item-object-category menu-item-31"><a href="#anounce">Anouncements</a></li>
<li id="menu-item-6677" class="section-support menu-item menu-item-type-post_type menu-item-object-page menu-item-6677"><a href="#">Support</a></li>
<li id="menu-item-31" class="section-news menu-item menu-item-type-taxonomy menu-item-object-category menu-item-31"><a href="#">Contact</a></li>

</ul></div>					<form role="search" method="get" class="search-form" action="https://www.ieconline.us/AstroCreatives.index.php">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>				</nav>
			</div>
		</header>