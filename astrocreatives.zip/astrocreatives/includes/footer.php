<footer id="colophon" class="site-footer" role="contentinfo">
			
			<div class="site-info">
				<div class="footer-subtext">
<div class="col-left"><img alt="logo" src="ASTRO-LOGO.svg" width="80px" height="50px" /><br/><br/>© Copyright 2023 Astro Group Of Companies<br>Afienya-Mataheko G/A</div>
<div class="col-mid"><a href="#">Terms of Use</a> and <a href="#">Privacy Policy</a></div>
<div class="col-right">Follow Us 
<a href="https://www.facebook.com/wonder.dzaikah" target="_blank">
	<img alt="Follow us on Facebook" src="https://www.teachersconnect.com/wp-content/uploads/2018/06/facebook.png" class="social_icon">
</a>
<a href="https://www.linkedin.com/in/dzaikah-wonder-984191232" target="_blank">
<img alt="Follow us on LinkedIn" src="https://www.teachersconnect.com/wp-content/uploads/2018/06/linkedin.png" class="social_icon">
</a>
 <a href="https://twitter.com/astro_ewiase" target="_blank">
<img alt="Follow us on Twitter" src="https://www.teachersconnect.com/wp-content/uploads/2018/06/twitter.png" class="social_icon">
</a> 

 </div></div>
			</div>
		</footer>