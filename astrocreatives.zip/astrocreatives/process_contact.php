<?php
 // Check if the form is submitted
// if (isset($_POST['submit'])) {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {    
    // Get the input values from the form
    $name = $_POST['name']; // Sender's name
    $email = $_POST['email']; // Sender's email
    $message = $_POST['message']; // Email message

    // // Validate the input values
    // if (empty($name) || empty($email) || empty($message)) {
    //     // Display an error message if any input is empty
    //     echo "Please fill in all the fields.";
    // } else {
        // Set the recipient email address
        $to = "astrodzaikah13@gmail.com"; // Change this to your own email address

        // Set the email headers
        $headers = "From: $name <$email>\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "Content-type: text/plain; charset=UTF-8\r\n";

        // Send the email using the mail() function
        if (mail($to, $message, $headers)) {
            // Display a success message if the email is sent
            echo "Your message has been sent successfully.";
        } else {
            // Display an error message if the email is not sent
            echo "There was an error sending your message.";
        }
    
    }

?>