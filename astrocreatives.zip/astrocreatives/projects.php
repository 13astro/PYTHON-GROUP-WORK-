
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>AstroCreatives</title>
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="https://www.teachersconnect.com/xmlrpc.php">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans|Montserrat' rel='stylesheet' type='text/css'>
	<!--[if lt IE 9]>
	<script src="https://www.teachersconnect.com/wp-content/themes/TC-Site/js/html5.js"></script>
	<![endif]-->
		<script type="text/javascript">function theChampLoadEvent(e){var t=window.onload;if(typeof window.onload!="function"){window.onload=e}else{window.onload=function(){t();e()}}}</script>
		<script type="text/javascript">var theChampDefaultLang = 'en_US', theChampCloseIconPath = 'https://www.teachersconnect.com/wp-content/plugins/super-socializer/images/close.png';</script>
		<script>var theChampSiteUrl = 'https://www.teachersconnect.com', theChampVerified = 0, theChampEmailPopup = 0, heateorSsMoreSharePopupSearchText = 'Search';</script>
			<script> var theChampSharingAjaxUrl = 'https://www.teachersconnect.com/wp-admin/admin-ajax.php', heateorSsFbMessengerAPI = 'https://www.facebook.com/dialog/send?app_id=595489497242932&display=popup&link=%encoded_post_url%&redirect_uri=%encoded_post_url%',heateorSsWhatsappShareAPI = 'web', heateorSsUrlCountFetched = [], heateorSsSharesText = 'Shares', heateorSsShareText = 'Share', theChampPluginIconPath = 'https://www.teachersconnect.com/wp-content/plugins/super-socializer/images/logo.png', theChampSaveSharesLocally = 0, theChampHorizontalSharingCountEnable = 0, theChampVerticalSharingCountEnable = 0, theChampSharingOffset = 0, theChampCounterOffset = -10, theChampMobileStickySharingEnabled = 1, heateorSsCopyLinkMessage = "Link copied.";
				</script>
			<style type="text/css">
						.the_champ_button_instagram span.the_champ_svg,a.the_champ_instagram span.the_champ_svg{background:radial-gradient(circle at 30% 107%,#fdf497 0,#fdf497 5%,#fd5949 45%,#d6249f 60%,#285aeb 90%)}
					.the_champ_horizontal_sharing .the_champ_svg,.heateor_ss_standard_follow_icons_container .the_champ_svg{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_horizontal_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_horizontal_sharing span.the_champ_svg:hover,.heateor_ss_standard_follow_icons_container span.the_champ_svg:hover{
				border-color: transparent;
	}
		.the_champ_vertical_sharing span.the_champ_svg,.heateor_ss_floating_follow_icons_container span.the_champ_svg{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_vertical_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_vertical_sharing span.the_champ_svg:hover,.heateor_ss_floating_follow_icons_container span.the_champ_svg:hover{
						border-color: transparent;
		}
	@media screen and (max-width:783px){.the_champ_vertical_sharing{display:none!important}}div.heateor_ss_mobile_footer{display:none;}@media screen and (max-width:783px){div.the_champ_bottom_sharing ul.the_champ_sharing_ul i.theChampTCBackground{background-color:white}div.the_champ_bottom_sharing{width:100%!important;left:0!important;}div.the_champ_bottom_sharing a{width:25% !important;margin:0!important;padding:0!important;}div.the_champ_bottom_sharing .the_champ_svg{width: 100% !important;}div.the_champ_bottom_sharing div.theChampTotalShareCount{font-size:1em!important;line-height:28px!important}div.the_champ_bottom_sharing div.theChampTotalShareText{font-size:.7em!important;line-height:0px!important}div.heateor_ss_mobile_footer{display:block;height:40px;}.the_champ_bottom_sharing{padding:0!important;display:block!important;width: auto!important;bottom:-2px!important;top: auto!important;}.the_champ_bottom_sharing .the_champ_square_count{line-height: inherit;}.the_champ_bottom_sharing .theChampSharingArrow{display:none;}.the_champ_bottom_sharing .theChampTCBackground{margin-right: 1.1em !important}}</style>
	<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	
	<link rel="canonical" href="www.ieconline.us/AstroCreatives/index.php" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="AstroCreatives - Your Design Our Priority" />
	<meta property="og:url" content="https://www.ieconline.us/AstroCreatives/index.php" />
	<meta property="og:site_name" content="TeachersConnect" />
	<meta property="article:publisher" content="https://www.facebook.com/TeachersConnect-552238004924723/" />
	<meta property="article:modified_time" content="2022-08-19T17:35:10+00:00" />
	<meta property="og:image" content="https://www.teachersconnect.com/wp-content/uploads/2020/01/icon-relentlessly-positive.png" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@teachconnect_us" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://www.ieconline.us/AstroCreatives/index.php","url":"https://www.ieconline.us/AstroCreatives/index.php","name":"AstroCreatives - Your Design Our Priority","isPartOf":{"@id":"https://www.teachersconnect.com/#website"},"primaryImageOfPage":{"@id":"https://www.teachersconnect.com/#primaryimage"},"image":{"@id":"https://www.teachersconnect.com/#primaryimage"},"thumbnailUrl":"https://www.teachersconnect.com/wp-content/uploads/2020/01/icon-relentlessly-positive.png","datePublished":"2020-01-29T19:10:27+00:00","dateModified":"2022-08-19T17:35:10+00:00","breadcrumb":{"@id":"https://www.teachersconnect.com/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://www.teachersconnect.com/"]}]},{"@type":"ImageObject","inLanguage":"en-US","@id":"https://www.teachersconnect.com/#primaryimage","url":"https://www.teachersconnect.com/wp-content/uploads/2020/01/icon-relentlessly-positive.png","contentUrl":"https://www.teachersconnect.com/wp-content/uploads/2020/01/icon-relentlessly-positive.png","width":60,"height":60},{"@type":"BreadcrumbList","@id":"https://www.teachersconnect.com/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home"}]},{"@type":"WebSite","@id":"https://www.teachersconnect.com/#website","url":"https://www.teachersconnect.com/","name":"TeachersConnect","description":"Say goodbye to teaching as a solo activity","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.teachersconnect.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel="alternate" type="application/rss+xml" title="TeachersConnect &raquo; Feed" href="https://www.teachersconnect.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="TeachersConnect &raquo; Comments Feed" href="https://www.teachersconnect.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.teachersconnect.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css' href='https://www.teachersconnect.com/wp-includes/css/dist/block-library/style.min.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='classic-theme-styles-css' href='https://www.teachersconnect.com/wp-includes/css/classic-themes.min.css?ver=1' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='wpos-slick-style-css' href='https://www.teachersconnect.com/wp-content/plugins/wp-logo-showcase-responsive-slider-slider/assets/css/slick.css?ver=3.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpls-public-style-css' href='https://www.teachersconnect.com/wp-content/plugins/wp-logo-showcase-responsive-slider-slider/assets/css/wpls-public.css?ver=3.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='ass-frontend-servers-css' href='https://www.teachersconnect.com/wp-content/plugins/atr-server-status/stylesheets/frontend-servers.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='crp-style-text-only-css' href='https://www.teachersconnect.com/wp-content/plugins/contextual-related-posts/css/text-only.min.css?ver=3.2.3' type='text/css' media='all' />
<link rel='stylesheet' id='wpos-font-awesome-css' href='https://www.teachersconnect.com/wp-content/plugins/wp-testimonial-with-widget/assets/css/font-awesome.min.css?ver=3.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='wtwp-public-css-css' href='https://www.teachersconnect.com/wp-content/plugins/wp-testimonial-with-widget/assets/css/wtwp-public.css?ver=3.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-fonts-css' href='https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C400%2C700%2C300italic%2C400italic%2C700italic%7CBitter%3A400%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css' href='https://www.teachersconnect.com/wp-content/plugins/jetpack/_inc/genericons/genericons/genericons.css?ver=3.1' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-style-css' href='https://www.teachersconnect.com/wp-content/themes/TC-Site/style.css?ver=2013-07-18' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css' href='https://www.teachersconnect.com/wp-content/themes/TC-Site/css/ie.css?ver=2013-07-18' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='the_champ_frontend_css-css' href='https://www.teachersconnect.com/wp-content/plugins/super-socializer/css/front.css?ver=7.13.43' type='text/css' media='all' />
<style id='the_champ_frontend_css-inline-css' type='text/css'>
.theChampSharingArrow{display:none!important}
ul.the_champ_sharing_ul:before{content: &quot;Share&quot;;font-size: 0.8em;}
</style>
<link rel='stylesheet' id='js_composer_front-css' href='https://www.teachersconnect.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.10.0' type='text/css' media='all' />
<link rel='stylesheet' id='shiftnav-css' href='https://www.teachersconnect.com/wp-content/plugins/shiftnav-responsive-mobile-menu/assets/css/shiftnav.min.css?ver=1.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='shiftnav-font-awesome-css' href='https://www.teachersconnect.com/wp-content/plugins/shiftnav-responsive-mobile-menu/assets/css/fontawesome/css/font-awesome.min.css?ver=1.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='shiftnav-custom-css' href='https://www.teachersconnect.com/wp-content/plugins/shiftnav-responsive-mobile-menu/custom/custom.css?ver=1.7.1' type='text/css' media='all' />
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/atr-server-status/javascript/server-functions.js?ver=6.1.1' id='ass-server-script-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://www.teachersconnect.com/wp-json/" /><link rel="alternate" type="application/json" href="https://www.teachersconnect.com/wp-json/wp/v2/pages/11483" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.teachersconnect.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.teachersconnect.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.1.1" />
<link rel='shortlink' href='https://www.teachersconnect.com/' />
<link rel="alternate" type="application/json+oembed" href="https://www.teachersconnect.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.teachersconnect.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://www.teachersconnect.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.teachersconnect.com%2F&#038;format=xml" />
<meta name="generator" content="Site Kit by Google 1.87.0" />
	
	<style type="text/css" id="shiftnav-dynamic-css">

	@media only screen and (min-width:768px){ #shiftnav-toggle-main, .shiftnav-toggle-mobile{ display:none; } .shiftnav-wrap { padding-top:0 !important; } }

/** ShiftNav Custom Menu Styles (Customizer) **/
/* togglebar */
#shiftnav-toggle-main { background:#e56841; }
#shiftnav-toggle-main.shiftnav-toggle-main-entire-bar:before, #shiftnav-toggle-main .shiftnav-toggle-burger { font-size:18px; }


/** ShiftNav Custom Tweaks (General Settings) **/
.shiftnav { background: #FFDB51; } .shiftnav-target { font-weight: bold; }
/* Status: Loaded from Transient */

	</style>
	

	<meta name="google-site-verification" content="IGyfwQz7SWumrUN3T5QfGOxWUYdp818w1U9k_utM3lg">

<meta name="google-adsense-platform-account" content="ca-host-pub-2644536267352236">
<meta name="google-adsense-platform-domain" content="sitekit.withgoogle.com">

<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
	<style type="text/css" id="twentythirteen-header-css">
			.site-title,
		.site-description {
			position: absolute;
			clip: rect(1px 1px 1px 1px); /* IE7 */
			clip: rect(1px, 1px, 1px, 1px);
		}
			.site-header .home-link {
			min-height: 0;
		}
		</style>
	

<script type="text/javascript">
			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-N25P2GS' );
			
</script>


<link rel="icon" href="ASTRO-LOGO.svg" sizes="32x32" />
<link rel="icon" href="ASTRO-LOGO.svg" sizes="192x192" />
<link rel="apple-touch-icon" href="ASTRO-LOGO.svg" />
<meta name="msapplication-TileImage" content="https://www.teachersconnect.com/wp-content/uploads/2021/04/cropped-cropped-cropped-TC-Web-App-Logo-300x300-1-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			a {
    color: #a02e0a !important;
    text-decoration: none;
}
You can add your own CSS here.

Click the help icon above to learn more.
*/

.home-banner .vc_single_image-img.attachment-full {
	max-width: 90%;
}

#page .yikes-easy-mc-form .yikes-easy-mc-submit-button {
	display: inline !important;
	margin-top: 30px !important;
	margin-left: 20px !important;
}

.top-rounded {
	border-top-left-radius: 20px;
border-top-right-radius: 20px;
}

.bottom-rounded {
	border-bottom-left-radius: 20px;
border-bottom-right-radius: 20px;
}

body, .navbar, .site-footer {
	background-color: #F9CE28;
}

body.archive h1.entry-title {
	line-height: 1.1 !important;
}

.entry-meta {
	margin-bottom: 20px;
}

.bm0 {
	margin-bottom: 0;
}

.tealblue {
	color: #224F59;
}

li {
	font-size: 0.9em;
}

#banner-top { display: none; }

.webinar-videos .vc_column-inner {
	padding-top: 0 !important;
}

.wpb_heading.wpb_video_heading {
	font-size: 1em;
	text-align: center;
	margin-bottom: 10px;
}

.vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-heading {
	border-color: #1A3E48;
	background-color: #F9CE28;
}

.vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-body, .vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-body::after, .vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-body::before {
	border-color: #1A3E48;
	border-top-color: #FFE37A;
	background-color: #FFE37A;
}

.vc_active .vc_tta-title-text {
	color: #224F59;
}

.vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-controls-icon::after, .vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-controls-icon::before {
	border-color: #E56841;
}

.vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-heading:focus, .vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-heading:hover {
	background: none;
}

.vc_tta-container .vc_tta-color-orange.vc_tta-style-classic .vc_tta-panel.vc_active .vc_tta-panel-heading {
	border-color: #1A3E48;
	background-color: #FFE37A;
}

.home #banner-top { display: block; }

#banner-top {
    height: 60px;
    padding: 15px;
    text-align: center;
    background: #36636D;
    color: #FFF;
}

#banner-top a { color: #FFFFFF !important; text-decoration: underline; }

#main { background: #F9CE28; }

#gated-content-survival-guide-1 {
	width: 50%;
	margin: 0 auto;
}

.yikes-easy-mc-form .yikes-easy-mc-submit-button {
	width: auto !important;
	margin: 0 auto !important;
	margin-top: 10px !important;
}

.survival-guide-download-button a {
	font-size: 1.4em !important;
}

.search #main { background: #E3E4E6; }

.menu-meta-site {
	clear: both;
	margin: 0 auto;
/* 	max-width: 1080px; */
	margin-top: 30px;
	padding-bottom: 30px;
	position: relative;
	border-bottom: solid 1px #A78400;
}

.menu-meta-site-container {
	padding: 0px 20px;
}

.menu-meta-site-links {
	float: right;
	margin: 0;
	padding: 0;
}

.menu-meta-site-links .link-button {
	float: left;
	margin-left: 30px;
	list-style: none;
	font-size: 0.7em;
	color: #a02e0a;
	padding: 5px 20px;
	border: 1px solid #a02e0a;
	border-radius: 5px;
}

.tcbutton.secondary a {
	background: none !important;
	border: 1px solid #E56841 !important;
	color: #E56841 !important;
	padding: 10px 20px !important;
}

.link-button.primary {
	background: #E56841;
	color: #FFFFFF;
	font-weight: 600;
	padding: 5px 10px;
}

.wptww-testimonial-content i, .wptww-testimonial-content h4, .wptww-testimonials-text em::before, .wptww-testimonials-text em::after {
	display: none;
}

.wptww-testimonial-client, .wptww-testimonial-job {
	color: #A78400;
}

.wptww-testimonials-slidelist .wptww-testimonials-text p {
	font-size: 20px;
	line-height: 1.4;
}

.wptww-testimonial-content {
	background: #FFFFFF;
	padding: 20px 20px 0px 20px;
	border-radius: 8px;
	margin-bottom: 10px;
	-webkit-box-shadow: 1px 1px 3px 0px rgba(167, 132, 0, 0.5);
-moz-box-shadow: 1px 1px 3px 0px rgba(167, 132, 0, 0.5);
box-shadow: 1px 1px 3px 0px
rgba(167, 132, 0, 0.5);
}

.wptww-testimonials-slidelist .slick-slide {
	padding: 0px 40px;
}

.wptww-testimonials-slidelist.design-1 .wptww-testimonial-client, .wptww-testimonials-slidelist.design-1 .wptww-testimonial-job {
	text-align: left;
	margin-left: 20px;
}

.wptww-testimonial-content::after {
	content: '';
	position: relative;
	border-left: 30px solid transparent;
	border-right: 30px solid transparent;
	border-top: 30px solid #FFF;
	clear: both;
	bottom: -55px;
	left: 90px;
}

.slick-dots {
	display: none !important;
}

.category-news .entry-title {
	padding-top: 20px;
}

footer.entry-meta {
	background: none;
}

.support_topics {
	margin-bottom: 20px !important; box-shadow: 1px 1px 3px #D4AA07;
}

.wpls-logo-showcase button.slick-prev, .wpls-logo-showcase button.slick-prev:active {
	background: rgba(249, 206, 40, 0.5) url('https://www.teachersconnect.com/wp-content/uploads/2018/07/arrow-left-red.svg') center center no-repeat !important;
	background-size: 8px 10px !important;
}

.wpls-logo-showcase button.slick-prev:hover, .wpls-logo-showcase button.slick-prev:focus {
	background: rgba(229, 104, 65, 1) url('https://www.teachersconnect.com/wp-content/uploads/2018/07/arrow-left.svg') center center no-repeat !important;
	background-size: 8px 10px !important;
}

.wpls-logo-showcase button.slick-next, .wpls-logo-showcase button.slick-next:active {
	background: rgba(249, 206, 40, 0.5) url('https://www.teachersconnect.com/wp-content/uploads/2018/07/arrow-right-red.svg') center center no-repeat !important;
	background-size: 8px 10px !important;
}

.wpls-logo-showcase button.slick-next:hover, .wpls-logo-showcase button.slick-next:focus {
	background: rgba(229, 104, 65, 1) url('https://www.teachersconnect.com/wp-content/uploads/2018/07/arrow-right.svg') center center no-repeat !important;
	background-size: 8px 10px !important;
}

article.category-news, .single-post article { background: #ffffff; border-radius: 8px; padding: 5px 10px; margin-bottom: 20px !important; box-shadow: 1px 1px 3px #D4AA07; max-width: 900px; margin: 0 auto; }

.category-news .entry-thumbnail img { width: 100% !important; border-radius: 8px; top: -20%; position: relative; margin-bottom: 0px;}

.category-news .entry-thumbnail { overflow: hidden; border-radius: 8px;     border: 1px solid #A78400; margin: 20px 0px; }

.single-post .category-news .entry-thumbnail { height: auto; }

.category-news #main, .category-news .crp-container, .category-support #main,  .paging-navigation { background: #F9CE28; }

.search .format-standard footer.entry-meta { display: none; }

.caldera-grid .alert-success { border-radius: 8px; padding: 20px; }

.keymsg_windowclassroom { background: url('https://www.teachersconnect.com/wp-content/uploads/2017/07/teacherclassroomchildren.jpg'); min-height: 400px; background-size: cover; background-position: center; }

.keymsg_answerquestions { background: url('https://www.teachersconnect.com/wp-content/uploads/2017/07/questionadultclassroom.jpg'); min-height: 400px; background-size: cover; background-position: center; }

.banner_teacherphonetc {min-height: 400px; background-size: cover; background-position: center; }

.banner_teacherslearning { background: url('https://www.teachersconnect.com/wp-content/uploads/2017/07/teacherslearning.jpg'); min-height: 450px; background-size: cover; background-position: center 30%; }

.keymsg_floattext { width: 350px; background: #F9CE28; border-radius: 15px 15px 0 0; padding: 20px 30px 0px; text-align: left; }

.keymsg_floattext h3 { margin: 0 !important; }

.keymsg_floattext.wpb_content_element { margin: 0 !important; }

.keymsg_bottom { position: absolute; bottom: 0; }

.staff_title { font-size: 12px; }

.staff_title h6 { margin: 15px 0 0 0; }

.staff_title img { max-width: 100px; }

.wide_500 { max-width: 500px !important; margin: 0 auto !important; padding: 0 30px; }

.wide_600 { max-width: 600px !important; margin: 0 auto !important; padding: 0 30px; }

.wide_900 { max-width: 900px !important; margin: 0 auto !important; padding: 0 30px; }

.wide_1000 { max-width: 1000px !important; margin: 0 auto !important; padding: 0 30px; }

.social_icon { margin-left: 10px; width: 25px; }

footer { padding-bottom: 50px; }

.below_button_text { margin-bottom: 10px !important; }

.text_below_button { font-size: 11px; }

.search .category-support { background: #f2f2f2; border-radius: 8px; padding: 5px 10px; margin-bottom: 20px !important; }

article.page.category-support { border-radius: 0 !important; margin-bottom: 0 !important; }

.entry-title { font-size: 32px; }

.post-331 { background: #f2f2f2; }

.bc-container, .crp-container, .contact-container { /*background: #f2f2f2;*/ padding: 30px; }

.breadcrumbs, .crp_related, .contactsupport, .search_pagetop { margin: 0 auto; max-width: 840px; width: 100%; }

.search_pagetop { padding: 20px 0; }

.search .post .entry-title a { font-size: 1.6rem !important; }

.contact-container { text-align: center; }

.contactsupport { padding-bottom: 40px; }

.question_list li { padding-bottom: 20px; list-style-type: none; }

.support_topics { text-align: center; padding: 0 20px; }

.support_topics img { margin: 0 20px; }

.widget_search { text-align: center; padding: 0; }

.search-submit { display: none; background: url(https://www.teachersconnect.com/wp-content/uploads/2017/08/icon-search.svg) #e56841 no-repeat!important; background-size: 20px!important; background-position: 7px!important; padding: 7px 17px!important; font-size: .8rem!important; width: 30px!important; text-indent: -99999999px; }

label[for=fld_7274063_1_opt1758332] { background: url(https://www.teachersconnect.com/wp-content/uploads/2017/08/Support-Request.png); }

label[for=fld_7274063_1_opt1414359] { background: url(https://www.teachersconnect.com/wp-content/uploads/2017/08/Feature-Request.png); }

label[for=fld_7274063_1_opt1365078] { background: url(https://www.teachersconnect.com/wp-content/uploads/2017/08/General-Inquiry.png); }

label[for=fld_7274063_1_opt1758332], label[for=fld_7274063_1_opt1414359], label[for=fld_7274063_1_opt1365078] { text-indent: -9999px; width: 160px; height: 186px; background-size: contain; background-repeat: no-repeat; margin-right: 30px; }

.bc-container { display: none; }

#fld_7274063Label { display: none; }

#fld_7274063_1-wrap { text-align: center; margin-bottom: 30px !important; }

.contact_requests img { max-width: 150px; }

.caldera-grid .row { margin-bottom: 15px; }

.wp-pagenavi { text-align: center; padding-bottom: 30px; }

.wp-pagenavi a, .wp-pagenavi span { margin: 0 15px; }

.search_pagetop .page-title {     padding: 30px 0; }

.search .entry-title { margin-bottom: 0px !important; }

.read-more-link { display: none; }

.contactsupport a button { margin-top: 20px; }

.post-url { color: #758282; font-size: 1.2em; }

.date { margin: 0 0 10px 0; font-size: 1.1em; color: #969D9D; }

.pathway_background { padding: 3px !important; cursor: pointer; }

.pathway_background .wpb_wrapper { /*height: 100%;*/ }

.pathway_layer { /*margin: 200px 0 0 0;*/ height: 300px; width: 80%; margin-bottom: 0; position: relative; }

.pathway_text { background: #E56841; color: #FFFFFF; font-weight: bold; line-height: 1.3; padding: 12px 30px; border-top-right-radius: 15px; text-align: center; position: absolute; bottom: 0; left: 0; }

.pathway_text a { color: #FFFFFF !important; }

.listing-item { text-align: left; }

.wp-video {
    text-align: center;
    margin-left: auto;
    margin-right: auto;

}

.the_champ_vertical_counter, .the_champ_vertical_sharing {
	bottom: 100px;
}

.staff-photo { border: 3px solid #224F59;  border-radius: 16px; background-color: #224F59;
}

.tc-video { box-shadow: 3px 3px 20px #444444; margin-left: 40px; margin-right: 40px}

.vc_custom_1509482996808 { border-radius: 5px; }

.vc_custom_1510079142204 { border-radius: 8px; }

.vc_custom_1510079151025 { border-radius: 8px; }

.vc_custom_1510076122081 { border-radius: 8px }

.vc_custom_1510077210293 { border-radius: 8px }

.vc_custom_1510076673378 { border-radius: 8px }

.card { border-radius: 4px; -moz-box-shadow: 1px 1px 3px #747474;
-webkit-box-shadow: 1px 1px 3px #747474;
box-shadow: 1px 1px 3px #747474; 
}

.card-image { margin-top: -20px; }

.card-text { margin-top: -20px;
margin-bottom: 15px; }

.card-text2 { margin-top: -25px;
margin-bottom: 10px; }

.tpp { width: 48%; margin-right: 10px; border-radius: 4px; -moz-box-shadow: 1px 1px 3px #747474;
-webkit-box-shadow: 1px 1px 3px #747474;
box-shadow: 1px 1px 3px #747474; }

.anotherway { width: 48%; margin-left: 10px; border-radius: 4px; -moz-box-shadow: 1px 1px 3px #747474;
-webkit-box-shadow: 1px 1px 3px #747474;
box-shadow: 1px 1px 3px #747474; }

.menu-item-30 a {
    border-bottom: none !important;
}

.menu-item-30 img {
    width: 220px;
}

hr {
    border: 1px solid #F9CE28 !important;
}

.mobile-center p {
	line-height: 1.2;
	padding-top: 7px;
}

@media (max-width:1020px) { 
	
.footer-subtext .col-left, .footer-subtext .col-mid, .footer-subtext .col-right { width: 100%; margin-bottom: 20px; text-align: center; }

.menu li a, .nav-menu li a { padding: 0; }

.ml40 { margin: 0 40px; }

#banner-top { font-size: 0.8em; height: auto; padding-right: 60px; }
	
.wptww-testimonial-content::after { display: none; }
	
.wptww-testimonial-content { padding-bottom: 20px; }

}

@media (max-width:783px) {

.the_champ_vertical_counter, .the_champ_vertical_sharing {     display: none !important; }

.keymsg_teacherbuilt { background: none !important; }

.tcbutton { text-align: center !important; }

.mobile-hide { display: none; }
	
.mobile-center p {
	text-align: center !important;
}

}


@media (max-width:610px) {
	
h1 { font-size: 1.6em; }

h1.entry-title { font-size: 1.4em; line-height: 1.2; }

h2 { font-size: 1.8em; margin: 0 0 20px 0; }

h3 { margin: 0 0 22px 0; text-align: center !important; }

h5 { font-size: 1em; }

.footer { margin: 0 20px; }

.footer .vc_column_container { margin-bottom: 20px; text-align: center; }

.mobile_paddingtop .vc_column-inner { padding-top: 0 !important; }

.keymsg_bottom .vc_column-inner { padding: 0 !important; }

.keymsg_answerquestions, .keymsg_windowclassroom { background-position: center -50px; min-height: 300px; }

.banner_teacherphonetc { min-height: 200px; }

.wpb_single_image { margin-bottom: 0 !important; }

.flex_text { order: 2; }

.flex_image { order: 1; }

.search-field { width: 80% !important; }

.widget_search, .bc-container, .crp-container, .contact-container { padding: 0 !important; }

.search_pagetop .page-title {     padding: 0; }

.category-support { padding: 0; }

.banner_teacherslearning { min-height: 240px; }

.wpb_single_image img { max-width: 60%; }

.wpb_single_image .vc_single_image-wrapper {     text-align: center; }

}



@media (max-width:330px) {


h3 { font-size: 26px; }

h5 {  }

.keymsg_floattext { border-radius: 0 !important; padding: 20px 50px 0px 10px; }

.support_topics img { margin: 0 10px; max-width: 100px; }

ul { padding: 0 0 0 10px; list-style-type: none; }

li { margin-bottom: 20px; }

.wide_900, .wide_600 { padding: 0 0 20px 20px; max-width: 100% !important; }

.widget_search, .bc-container, .crp-container { padding: 0 !important; max-width: 90%; margin: 0 auto; }

.crp-container h5 { text-align: center; }

.contact-container { padding: 0 !important; max-width: 80%; margin: 0 auto; }

.contactsupport button { margin-top: 20px; }

.crp_related ul { padding: 0px 0px 0px 40px; }

.breadcrumbs { font-size: 0.8em; }

.wpb_single_image img { max-width: 100%; }

}

@media (min-width:1020px) { 
	
.col-left { padding-left: 105px; }

.col-right { padding-right: 80px; }

}

		</style>
		<style type="text/css" data-type="vc_custom-css">.page-id-5 .banner-top {
display:none;
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1509482837041{padding-top: 50px !important;}.vc_custom_1498064631928{background-color: #f9ce28 !important;}.vc_custom_1579730944077{padding-top: 0px !important;padding-bottom: 0px !important;background-color: #f9ce28 !important;}.vc_custom_1598999631426{padding-top: 0px !important;padding-bottom: 0px !important;background-color: #ffe37a !important;}.vc_custom_1598999639487{padding-top: 0px !important;padding-bottom: 0px !important;background-color: #ffe37a !important;}.vc_custom_1598999644941{background-color: #ffe37a !important;}.vc_custom_1579634751763{background-color: #f9ce28 !important;}.vc_custom_1579634733835{background-color: #f9ce28 !important;}.vc_custom_1525201365761{margin-bottom: 20px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
<style>
body {
	background-image: url('img/geo.jpg');
	background-size: cover;
	height: 100vh; /* Adjust the height as needed */
}


.buttons{
    display:flex;
    justify-content:center;
    align-items:center;
    height:10vh;
    overflow-x: scroll;
    white-space: nowrap;
}
.buttons button {
  margin-right: 5px;
}
    
}
.hello {
  opacity: 1 !important;
}
.full {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}
.full .content {
  background-color: rgba(0,0,0,0.75) !important;
  height: 100%;
  width: 100%;
  display: grid;
}
.full .content img {
  left: 50%;
  transform: translate3d(0, 0, 0);
  animation: zoomin 1s ease;
  max-width: 100%;
  max-height: 100%;
  margin: auto;
}
.byebye {
  opacity: 0;
}
.byebye:hover {
  transform: scale(0.2) !important;
}
.gallery {
  display: grid;
  grid-column-gap: 8px;
  grid-row-gap: 8px;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  grid-auto-rows: 8px;
}
.gallery img {
  max-width: 100%;
  border-radius: 8px;
  box-shadow: 0 0 16px #333;
  transition: all 1.5s ease;
}
.gallery img:hover {
  box-shadow: 0 0 32px #333;
}
.gallery .content {
  padding: 4px;
}
.gallery .gallery-item {
  transition: grid-row-start 300ms linear;
  transition: transform 300ms ease;
  transition: all 0.5s ease;
  cursor: pointer;
}
.gallery .gallery-item:hover {
  transform: scale(1.025);
}
@media (max-width: 600px) {
  .gallery {
    grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
  }
}
@media (max-width: 400px) {
  .gallery {
    grid-template-columns: repeat(auto-fill, minmax(50%, 1fr));
  }
}
@-moz-keyframes zoomin {
  0% {
    max-width: 50%;
    transform: rotate(-30deg);
    filter: blur(4px);
  }
  30% {
    filter: blur(4px);
    transform: rotate(-80deg);
  }
  70% {
    max-width: 50%;
    transform: rotate(45deg);
  }
  100% {
    max-width: 100%;
    transform: rotate(0deg);
  }
}
@-webkit-keyframes zoomin {
  0% {
    max-width: 50%;
    transform: rotate(-30deg);
    filter: blur(4px);
  }
  30% {
    filter: blur(4px);
    transform: rotate(-80deg);
  }
  70% {
    max-width: 50%;
    transform: rotate(45deg);
  }
  100% {
    max-width: 100%;
    transform: rotate(0deg);
  }
}
@-o-keyframes zoomin {
  0% {
    max-width: 50%;
    transform: rotate(-30deg);
    filter: blur(4px);
  }
  30% {
    filter: blur(4px);
    transform: rotate(-80deg);
  }
  70% {
    max-width: 50%;
    transform: rotate(45deg);
  }
  100% {
    max-width: 100%;
    transform: rotate(0deg);
  }
}
@keyframes zoomin {
  0% {
    max-width: 50%;
    transform: rotate(-30deg);
    filter: blur(4px);
  }
  30% {
    filter: blur(4px);
    transform: rotate(-80deg);
  }
  70% {
    max-width: 50%;
    transform: rotate(45deg);
  }
  100% {
    max-width: 100%;
    transform: rotate(0deg);
  }
}




</style>
</head>

<body class="home page-template-default page page-id-11483 wpb-js-composer js-comp-ver-6.10.0 vc_responsive">
	<div id="page" class="hfeed site">
		<?php include('includes/header.php'); ?>

		<div id="main" class="site-main">
 <!-- <div class="gallery" id="gallery">
        <div class="gallery-item" category="web">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,care" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,studied" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,substance" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,choose" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,past" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,lamp" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,yet" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,eight" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,crew" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,event" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,instrument" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,practical" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,pass" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,bigger" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,number" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,feature" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,line" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,railroad" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,pride" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,too" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,bottle" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,base" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,cell" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,bag" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,card" alt=""></div>
        </div>
    </div>-->
		    
<div class="buttons">
    <button onclick="filterImages('all')">All</button>
    <button onclick="filterImages('web')">Website</button>
    <button onclick="filterImages('flyer')">Flyers</button>
    <button onclick="filterImages('logo')">Logos</button>
    <button onclick="filterImages('banner')">Banners</button>
   <!-- <button onclick="filterImages('lamp')">Lamp</button>
    <button onclick="filterImages('yet')">Yet</button>
    <button onclick="filterImages('eight')">Eight</button>-->
</div>

<div class="gallery" id="gallery">
    <div class="gallery-item" data-category="flyer">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,care" alt=""></div>
    </div>
    <div class="gallery-item" data-category="web">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,studied" alt=""></div>
    </div>
    <div class="gallery-item" data-category="flyer">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,substance" alt=""></div>
    </div>
    <div class="gallery-item" data-category="logo">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,choose" alt=""></div>
    </div>
    <div class="gallery-item" data-category="logo">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,past" alt=""></div>
    </div>
    <div class="gallery-item" data-category="banner">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,lamp" alt=""></div>
    </div>
    <div class="gallery-item" data-category="web">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,yet" alt=""></div>
    </div>
    <div class="gallery-item" data-category="flyer">
        <div class="content"><img src="https://source.unsplash.com/random/?tech,eight" alt=""></div>
    </div>
    <div class="gallery-item" >
            <div class="content"><img src="https://source.unsplash.com/random/?tech,number" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,feature" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,line" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,railroad" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,pride" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,too" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,bottle" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,base" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,cell" alt=""></div>
        </div>
        <div class="gallery-item">
            <div class="content"><img src="https://source.unsplash.com/random/?tech,bag" alt=""></div>
        </div>
        

</div>


		<?php include('includes/footer.php'); ?>

	</div>

</div>
<script>
jQuery(document).ready(function () {
	jQuery(".pathway_background").click(function() {
  		window.location = jQuery(this).find("a").attr("href");
  		return false;
	});
});
</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-69936049-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-69936049-1');
</script>


	<script type="text/javascript">
	var Servers = []</script>
<script type="text/javascript">
	var ATR_Ajaxurl = "https://www.teachersconnect.com/wp-admin/admin-ajax.php";
	var Settings = {"request-execution-order":"async","attempt-prevent-cache":"no","follow-location":1,"max-redirs":5,"ssl-verifypeer":1,"ssl-verifyhost":1,"hide-promotions":0}</script>
	
		<div id="shiftnav-toggle-main" class="shiftnav-toggle-main-align-center shiftnav-toggle-style-burger_only shiftnav-togglebar-gap-off shiftnav-toggle-edge-right shiftnav-toggle-icon-x"   ><button id="shiftnav-toggle-main-button" class="shiftnav-toggle shiftnav-toggle-shiftnav-main shiftnav-toggle-burger" tabindex="1" data-shiftnav-target="shiftnav-main" aria-label="Toggle Menu"><i class="fa fa-bars"></i></button>	</div>	
	

	


	
	<div class="shiftnav shiftnav-nojs shiftnav-shiftnav-main shiftnav-right-edge shiftnav-skin-custom shiftnav-transition-standard" id="shiftnav-main" data-shiftnav-id="shiftnav-main">
		<div class="shiftnav-inner">

		
		<nav class="shiftnav-nav">
	<ul id="menu-mobile-menu" class="shiftnav-menu shiftnav-targets-large shiftnav-targets-text-large shiftnav-targets-icon-default">
	<li id="menu-item-11510" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-11483 current_page_item menu-item-11510 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="index.php">Home</a></li>
	<li id="menu-item-11441" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11441 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">About Me</a></li>
	<li id="menu-item-8692" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8692 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">Projects</a></li>
	<li id="menu-item-11440" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11440 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">Testimonials</a></li>
	<li id="menu-item-8694" class="section-news menu-item menu-item-type-taxonomy menu-item-object-category menu-item-8694 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">Anouncements</a></li>
	<li id="menu-item-8693" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8693 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">Support</a></li>
	<li id="menu-item-8690" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8690 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="#">Contact</a></li>
	<li id="menu-item-8911" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8911 shiftnav-depth-0">
	 <a class="shiftnav-target"  href="login.html">Log Out</a></li></ul></nav>
		<button class="shiftnav-sr-close shiftnav-sr-only shiftnav-sr-only-focusable">
			&times; Close Panel		</button>

		</div>
	</div>


			
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N25P2GS" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		
		<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/atr-server-status/javascript/frontend-check-servers-async.js?ver=6.1.1' id='ass-frontend-check-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/themes/TC-Site/js/functions.js?ver=20150330' id='twentythirteen-script-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/super-socializer/js/front/social_login/general.js?ver=7.13.43' id='the_champ_ss_general_scripts-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/super-socializer/js/front/sharing/sharing.js?ver=7.13.43' id='the_champ_share_counts-js'></script>
<script type='text/javascript' id='shiftnav-js-extra'>
/* <![CDATA[ */
var shiftnav_data = {"shift_body":"on","shift_body_wrapper":"","lock_body":"on","lock_body_x":"off","open_current":"off","collapse_accordions":"off","scroll_panel":"on","breakpoint":"768","v":"1.7.1","pro":"0","touch_off_close":"on","scroll_offset":"100","disable_transforms":"off","close_on_target_click":"off","scroll_top_boundary":"50","scroll_tolerance":"10","process_uber_segments":"on"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/shiftnav-responsive-mobile-menu/assets/js/shiftnav.min.js?ver=1.7.1' id='shiftnav-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.10.0' id='wpb_composer_front_js-js'></script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/wp-logo-showcase-responsive-slider-slider/assets/js/slick.min.js?ver=3.2.1' id='wpos-slick-jquery-js'></script>
<script type='text/javascript' id='wtwp-public-script-js-extra'>
/* <![CDATA[ */
var Wtwp = {"is_rtl":"0","is_avada":"0","elementor_preview":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.teachersconnect.com/wp-content/plugins/wp-testimonial-with-widget/assets/js/wtwp-public.js?ver=3.1.1' id='wtwp-public-script-js'></script>

<script>
    var gallery = document.querySelector('#gallery');
var getVal = function (elem, style) { return parseInt(window.getComputedStyle(elem).getPropertyValue(style)); };
var getHeight = function (item) { return item.querySelector('.content').getBoundingClientRect().height; };
var resizeAll = function () {
    var altura = getVal(gallery, 'grid-auto-rows');
    var gap = getVal(gallery, 'grid-row-gap');
    gallery.querySelectorAll('.gallery-item').forEach(function (item) {
        var el = item;
        el.style.gridRowEnd = "span " + Math.ceil((getHeight(item) + gap) / (altura + gap));
    });
};
gallery.querySelectorAll('img').forEach(function (item) {
    item.classList.add('byebye');
    if (item.complete) {
        console.log(item.src);
    }
    else {
        item.addEventListener('load', function () {
            var altura = getVal(gallery, 'grid-auto-rows');
            var gap = getVal(gallery, 'grid-row-gap');
            var gitem = item.parentElement.parentElement;
            gitem.style.gridRowEnd = "span " + Math.ceil((getHeight(gitem) + gap) / (altura + gap));
            item.classList.remove('byebye');
        });
    }
});
window.addEventListener('resize', resizeAll);
gallery.querySelectorAll('.gallery-item').forEach(function (item) {
    item.addEventListener('click', function () {        
        item.classList.toggle('full');        
    });
});

</script>
<script>
    function filterImages(category) {
    var galleryItems = document.getElementsByClassName('gallery-item');
    if (category === 'all') {
        for (var i = 0; i < galleryItems.length; i++) {
            galleryItems[i].style.display = 'block';
        }
    } else {
        for (var i = 0; i < galleryItems.length; i++) {
            if (galleryItems[i].getAttribute('data-category') !== category) {
                galleryItems[i].style.display = 'none';
            } else {
                galleryItems[i].style.display = 'block';
            }
        }
    }
}
</script>
</body>
</html>
